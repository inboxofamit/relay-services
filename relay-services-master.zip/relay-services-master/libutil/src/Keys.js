'use strict';

module.exports = {
  paymentPublic: __dirname + '/../public/payment-service-public.txt',
  noncePublic: __dirname + '/../public/nonce-service-public.txt',
  corePublic: __dirname + '/../public/core-service-public.txt'
};