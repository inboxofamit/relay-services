# libredis
A thin promisified wrapper around Redis
