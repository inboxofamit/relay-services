# libencrypt
A thin promisified wrapper around PGP encryption
